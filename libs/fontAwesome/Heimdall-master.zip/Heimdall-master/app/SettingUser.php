<?php

namespace App;

use Illuminate\Database\Eloquent\Relations\Pivot;

class SettingUser extends Pivot
{
    //
}

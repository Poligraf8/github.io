<?php

namespace App;

use Illuminate\Database\Eloquent\Relations\Pivot;

class ItemTag extends Pivot
{
    
}
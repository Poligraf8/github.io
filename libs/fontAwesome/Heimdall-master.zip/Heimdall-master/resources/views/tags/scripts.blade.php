<script>
        $( function() {

            var elem = $('.color-picker')[0];
            var hueb = new Huebee( elem, {
              // options
            });        

        });
</script>